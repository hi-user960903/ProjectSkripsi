<!--Footer-->
<footer class="footer_wrapper" id="contact_periksa">
  <div class="container">
    <section class="page_section contact" id="contact_periksa">
    </section>
  </div>
  <div class="container">
    <div class="footer_bottom"><span>Copyright © 2014 <a href="#">SiPPerS</a>. </span> </div>
  </div>
</footer>

<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery-scrolltofixed.js"></script>
<script type="text/javascript" src="js/jquery.nav.js"></script> 
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="js/jquery.isotope.js"></script>
<script type="text/javascript" src="js/wow.js"></script> 
<script type="text/javascript" src="js/custom.js"></script>

</body>
</html>
