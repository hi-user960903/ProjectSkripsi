<?php
echo"<h2><a  href='?page=input_kerusakan'><i class='fa fa-plus'></i> Tambah Kerusakan</a></h2><hr>";

$pinjam			= date("d-m-Y");
$tuju_hari		= mktime(0,0,0,date("n"),date("j")+7,date("Y"));
$kembali		= date("d-m-Y", $tuju_hari);
?>
<div class="jumbotron">

<center><h4>Solusi</h4></center>
<br>
<form class="form-horizontal" method="post" action="?page=act_input_kerusakan">
  <div class="form-group">
    <label for="Gejala" class="col-md-3 col-md-offset-1 control-label">Nama</label>
    <div class="col-sm-5">
      <input type="text" class="form-control" name="nama_kerusakan">
    </div>
  </div>
    <div class="form-group">
    <label for="Gejala" class="col-md-3 col-md-offset-1 control-label">Penyebab</label>
    <div class="col-sm-5">
      <input type="text" class="form-control" name="penyebab">
    </div>
  </div>
      <div class="form-group">
    <label for="Gejala" class="col-md-3 col-md-offset-1 control-label">Solusi</label>
    <div class="col-sm-5">
      <input type="text" class="form-control" name="solusi">
    </div>
  </div>
   <div class="form-group">
    <label for="Gejala" class="col-md-3 col-md-offset-1 control-label">Perawatan</label>
    <div class="col-sm-5">
      <input type="text" class="form-control" name="perawatan">
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-offset-4 col-sm-5">
      <button type="submit" class="btn btn-theme">Tambah</button>
    </div>
  </div>
</form>
</div>
