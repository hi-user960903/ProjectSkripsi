<?php
error_reporting(0);
include "../config/koneksi.php";
echo "<h2><a  href='?page=edit_kerusakan'><i class='fa fa-edit'></i> Edit Kerusakan</a></h2><hr>";

$id=$_GET['id'];
if ($id=="") {
echo "<script>alert('Pilih dulu data yang akan di-update');</script>";
echo "<meta http-equiv='refresh' content='0; url=?page=kerusakan'>";
} else {

$query=mysqli_query($con,"SELECT * FROM solusi WHERE id_solusi=$id");
$hasil=mysqli_fetch_array($query,MYSQLI_ASSOC);
$id  =$hasil['id_solusi'];

$nama_kerusakan=$hasil['nama_kerusakan'];
$penyebab =$hasil['penyebab'];
$solusi=$hasil['solusi'];
$perawatan=$hasil['perawatan'];


?>

<div class="jumbotron">

<center><h4>Rule Diagnosa</h4></center>
<br>
<form class="form-horizontal" method="post" action="?page=act_edit_kerusakan">
<input type="hidden" name="id" value="<?php echo $id; ?>">
  <div class="form-group">
    <label for="Gejala" class="col-md-3 col-md-offset-1 control-label">Edit Solusi</label>
    <div class="col-sm-5">
      <input type="text" class="form-control" name="nama_kerusakan" value="<?php echo $nama_kerusakan; ?>">
    </div>
  </div>
  <div class="form-group">
    <label for="Gejala" class="col-md-3 col-md-offset-1 control-label">Nama</label>
    <div class="col-sm-5">
      <input type="text" class="form-control" name="nama_kerusakan" value="<?php echo $nama_kerusakan; ?>">
    </div>
  </div>
  <div class="form-group">
    <label for="Gejala" class="col-md-3 col-md-offset-1 control-label">Penyebab</label>
    <div class="col-sm-5">
      <input type="text" class="form-control" name="penyebab" value="<?php echo $penyebab; ?>">
    </div>
  </div>
    <div class="form-group">
    <label for="Gejala" class="col-md-3 col-md-offset-1 control-label">Solusi</label>
    <div class="col-sm-5">
      <input type="text" class="form-control" name="solusi" value="<?php echo $solusi; ?>">
    </div>
  </div>
    <div class="form-group">
    <label for="Gejala" class="col-md-3 col-md-offset-1 control-label">Perawatan</label>
    <div class="col-sm-5">
      <input type="text" class="form-control" name="perawatan" value="<?php echo $perawatan; ?>">
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-offset-4 col-sm-5">
      <button type="submit" class="btn btn-theme">Simpan</button>
    </div>
  </div>
</form>
</div>
<?php
}
?>
