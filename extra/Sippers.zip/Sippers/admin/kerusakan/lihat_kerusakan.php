<?php
include "../config/koneksi.php"; //memanggil file koneksi_db.php
include "../config/fungsi.php";
include "../config/class_paging.php";
echo"<h2><a  href='?page=kerusakan'><i class='fa fa-list-alt'></i> Data Kerusakan</a></h2><hr>";


$p      = new Paging;
$batas  = 10;
$posisi = $p->cariPosisi($batas);


$query=mysqli_query($con,"SELECT * from solusi order by id_solusi desc LIMIT $posisi,$batas");
?>
 
<form method="post" action="?page=input_kerusakan">
<br><table class="table table-bordered table-striped ">
    <thead class="cf">
    <tr>
	<th>No</th>
	<th>Nama</th>
	<th>Penyebab</th>
	<th>Solusi </th>
	<th>Perawatan </th>
	<th colspan='2'>Action</th>
	</tr>
	</thead>
    <tbody>
<?php
$no=$posisi+1;;
while ($hasil=mysqli_fetch_array($query,MYSQLI_ASSOC)) {

echo "<tr>
	  <td>$no</td>
	  <td>$hasil[nama_kerusakan]</td>
	  <td>$hasil[penyebab]</td>
	  <td>$hasil[solusi]</td>
	  <td>$hasil[perawatan]</td>
	  <td><a href='?page=edit_kerusakan&id=$hasil[id_solusi]'> <button type='button' class='btn btn-theme'><i class='fa fa-edit'></i></button></a></td>
	  <td><a href='?page=hapus_kerusakan&id=$hasil[id_solusi]' onclick='return confirm(\"Anda yakin ingin menghapus data ini ?\")'>  <button type='button' class='btn btn-danger'> <i class='fa fa-trash-o'></i></button></a></td>
	  </tr>";
$no++;
}
echo'</tbody></table>
<center><button class="btn btn-theme" type="submit" >Tambah</button></center>';
	$jmldata = mysqlI_num_rows(mysqlI_query($con,"SELECT * FROM solusi"));
    $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
    $linkHalaman = $p->navHalaman($_GET['halaman'], $jmlhalaman);

echo "<div id=paging>Hal: $linkHalaman</div><br>";


?>