    <!--sidebar start-->
      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu" id="nav-accordion">
              
              	  
                  <li class="mt">
                      <a href="../../index.php">
                          <i class="fa fa-home"></i>
                          <span>Home</span>
                      </a>
                  </li>
				  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-desktop"></i>
                          <span>Naive Bayes</span>
                      </a>
                      <ul class="sub">
                        <li class="Sub-menu">
							<a>
								<i class="fa fa-desktop"></i>
								<span>Gejala</span>
							</a>
						  
							<ul class="sub">
								<li><a  href="?page=input_gejala_penyakit"><i class="fa fa-plus"></i>Tambah Gejala Penyakit</a></li>
								<li><a  href="?page=gejala_penyakit"><i class="fa fa-folder-open"></i>Data Gejala Penyakit</a></li>
							</ul>
						</li>
						<li class="Sub-menu">
							<a>
								<i class="fa fa-desktop"></i>
								<span>Atribut Gejala</span>
							</a>
						  
							<ul class="sub">
								<li><a  href="?page=input_atribut_penyakit"><i class="fa fa-plus"></i>Tambah Atribut Gejala Penyakit</a></li>
								<li><a  href="?page=atribut_penyakit"><i class="fa fa-folder-open"></i>Data Atribut Gejala Penyakit</a></li>
							</ul>
						</li>
						<li class="Sub-menu">
							<a>
								<i class="fa fa-desktop"></i>
								<span>Solusi</span>
							</a>
						  
							<ul class="sub">
								<li><a  href="?page=input_penyakit"><i class="fa fa-plus"></i>Tambah Solusi</a></li>
								<li><a  href="?page=penyakit"><i class="fa fa-folder-open"></i>Data Solusi</a></li>
							</ul>
						</li>
				   <!-- <li class="Sub-menu">
							<a>
								<i class="fa fa-desktop"></i>
								<span>Solusi</span>
							</a>
							<ul class="sub">
								<li><a  href="?page=input_solusi"><i class="fa fa-plus"></i>Tambah Solusi</a></li>
								<li><a  href="?page=solusi"><i class="fa fa-folder-open"></i>Data Solusi</a></li>
							</ul>
						</li>-->
						<li class="Sub-menu">
							<a href="?page=probabilitas">
								<i class="fa fa-desktop"></i>
								<span>Tabel Probabilitas</span>
							</a>
						</li>
                     </ul>
                  </li>
					<li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-desktop"></i>
                          <span>Forward Chaining</span>
                      </a>
                      <ul class="sub">
                        <li class="Sub-menu">
							<a>
								<i class="fa fa-desktop"></i>
								<span>Rule Diagnosa</span>
							</a>
						  
							<ul class="sub">
								<li><a  href="?page=input_rule_diagnosa"><i class="fa fa-plus"></i>Tambah Rule Diagnosa</a></li>
								<li><a  href="?page=rule_diagnosa"><i class="fa fa-folder-open"></i>Data Rule Diagnosa</a></li>
							</ul>
						</li>
						<li class="Sub-menu">
							<a>
								<i class="fa fa-desktop"></i>
								<span>Relasi Memiliki</span>
							</a>
						  
							<ul class="sub">
								<li><a  href="?page=input_memiliki"><i class="fa fa-plus"></i>Tambah Relasi Memiliki</a></li>
								<li><a  href="?page=memiliki"><i class="fa fa-folder-open"></i>Data Relasi Memiliki</a></li>
							</ul>
						</li>
						<li class="Sub-menu">
							<a>
								<i class="fa fa-desktop"></i>
								<span>Solusi</span>
							</a>
							<ul class="sub">
								<li><a  href="?page=input_kerusakan"><i class="fa fa-plus"></i>Tambah Solusi</a></li>
								<li><a  href="?page=kerusakan"><i class="fa fa-folder-open"></i>Data Solusi</a></li>
							</ul>
						</li>
                     </ul>
                  </li>		
				   <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-book"></i>
                          <span>Informasi Beranda</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="?page=kamus"><i class="fa fa-folder-open"></i>Data Informasi</a></li>
                     </ul>
                  </li>
				  
				  <li class="sub-menu">
                      <a href="?page=histori">
                          <i class="fa fa-list-alt"></i>
                          <span>Histori Pasien</span>
                      </a>
                  </li>
				  
                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-users"></i>
                          <span>Data Pengguna</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="?page=input_user"><i class="fa fa-plus"></i>Tambah Pengguna</a></li>
                          <li><a  href="?page=user"><i class="fa fa-folder-open"></i>Data Pengguna</a></li>
                       </ul>
                  </li>
                 
              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>
      <!--sidebar end-->