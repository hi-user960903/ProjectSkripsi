<?php
error_reporting(E_ALL);
include "../config/koneksi.php"; //memanggil file koneksi_db.php
include "../config/config.php"; //memanggil file fungsi.php
include "../config/fungsi.php"; //memanggil file fungsi.php


$user 		= $_POST['user'];
$pass 		= md5($_POST['pass']);
$nama 		= $_POST['nama'];
$pekerjaan	= $_POST['pekerjaan'];
$alamat 	= $_POST['alamat'];
$tgl_lahir 	= $_POST['tgl_lahir'];
$level 		= $_POST['level'];
$hasil		= $_POST['hasil_persalinan'];
$count		= $_POST['count'];

If ($user==""&&$pass==""&&$nama==""&&$pekerjaan==""&&$alamat==""&&$tgl_lahir==""&&$level==""&&hasil=="") {
	Echo "Pengisian form belum benar. Ulangi lagi";
	echo "<meta http-equiv='refresh' content='0; url=?page=user'>";
} else {
	$sql ="INSERT INTO daftar_user( id_user, 
									username, 
									nama, 
									level, 
									password, 
									pekerjaan, 
									alamat, 
									tgl_lahir, 
									hasil) 
							VALUES ('',
									'$user',
									'$nama', 
									'$level', 
									'$pass', 
									'$pekerjaan', 
									'$alamat', 
									'$tgl_lahir', 
									'$hasil')";

if ($con->query($sql) === TRUE) {
	
    $last_id = $con->insert_id;
	for ($i=0; $i<$count; $i++)
	{
	$gejala		= $_POST['id_gejala_'.$i];
	$atribut	= $_POST['id_atribut_'.$i];
	
	$sql=mysqli_query($con, "Insert into daftar_memiliki (  id, 
															id_user, 
															id_gejala, 
															id_atribut) 
												values   (	' ',
															'$last_id',
															'$gejala',
															'$atribut')
															");	
	}
	
} else {
   if (!$sql) {
    printf("Error: %s\n", mysqli_error($con));
    exit();
}   
}

If ($sql) {

Echo "<meta http-equiv='refresh' content='0; url=?page=user'>";
} else {
Echo "Data anda gagal dimasukkan. Ulangi sekali lagi";
echo "<meta http-equiv='refresh' content='0; url=?page=user'>";
}

}
?>
