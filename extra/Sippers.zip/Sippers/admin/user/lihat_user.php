<?php
include "../config/koneksi.php"; //memanggil file koneksi_db.php
echo"<h2><a  href='?page=user'><i class='fa fa-list-alt'></i> User</a></h2><hr>";

?>
<ul class="nav nav-tabs" id="myTab" role="tablist">
  <li class="nav-item">
    <a  class="btn btn-warning btn-md" id="user-tab" data-toggle="tab" href="#user" role="tab" aria-controls="user" aria-selected="false">Data Pengguna Pasien</a>
  </li>
  <li class="nav-item">
    <a class="btn btn-warning btn-md" class="nav-link" id="admin-tab" data-toggle="tab" href="#admin" role="tab" aria-controls="admin" aria-selected="false">Data Pengguna Admin</a>
  </li>
</ul>
<br/>	
<div class="tab-content" id="myTabContent">
  <div class="tab-pane fade" id="user" role="tabpanel" aria-labelledby="user-tab">
	<form class="col-md-12">
		<table class="table table-bordered table-striped" >
		<thead class="cf">
		<tr>
			<th style="width:30px;" >No</th>
			<th >Nama</th>
			<th >Level</th>
			<th >tgl_lahir</th>
			<th width="10px">Tes</th>
			<th colspan="2" class="col-md-1"><center>Action</center></th></tr>
		</thead>
		<tbody>
		<?php
		$query=mysqli_query($con,"SELECT * FROM daftar_user WHERE level='pasien' ORDER BY id_user");
		$no=0;
		while ($hasil=mysqli_fetch_array($query)) {
		$no++;
		echo "<tr><td>$no</td>
			  <th >Nama</th>
			  <td>$hasil[level]</td>
			  <td>$hasil[tgl_lahir]</td>
			  <td><a href='../../periksa.php?id=$hasil[id_user]'> <button type='button' class='btn btn-success'><i class='fa fa-medkit'></i></button></a></td>
			  <td><a href='?page=edit_user&id=$hasil[id_user]'> <button type='button' class='btn btn-theme'><i class='fa fa-edit'></i></button></a></td>
			  <td><a href='?page=act_hapus_user&id=$hasil[id_user]' onclick='return confirm(\"Anda yakin ingin menghapus data ini ?\")'> <button type='button' class='btn btn-danger'> <i class='fa fa-trash-o'></i></button></a></td></tr>
			  ";
			  
		}
		?>
		</tbody>
		</table>
	</form>  
  </div>
  <div class="tab-pane fade" id="admin" role="tabpanel" aria-labelledby="admin-tab">
	<form class="col-md-12">
		<table class="table table-bordered table-striped" >
		<thead class="cf">
		<tr>
			<th style="width:30px;" >No</th>
			<th >Username</th>
			<th >Level</th>
			<th >Nama</th>
			<th style="width:100px;">tgl_lahir</th>
			<th colspan="2" class="col-md-1"><center>Action</center></th></tr>
		</thead>
		<tbody>
		<?php
		$query=mysqli_query($con,"SELECT * FROM daftar_user WHERE level='admin' ORDER BY id_user");
		$no=0;
		while ($hasil=mysqli_fetch_array($query)) {
		$no++;
		echo "<tr><td>$no</td>
			  <td>$hasil[username]</td>
			  <td>$hasil[level]</td>
			  <td>$hasil[nama]</td>
			  <td>$hasil[tgl_lahir]</td>
			  <td><a href='?page=edit_user&id=$hasil[id_user]'> <button type='button' class='btn btn-theme'><i class='fa fa-edit'></i></button></a></td>
			  <td><a href='?page=act_hapus_user&id=$hasil[id_user]' onclick='return confirm(\"Anda yakin ingin menghapus data ini ?\")'> <button type='button' class='btn btn-danger'> <i class='fa fa-trash-o'></i></button></a></td></tr>";
		}
		?>
		</tbody>
		</table>
	</form>  
  </div>
</div>

