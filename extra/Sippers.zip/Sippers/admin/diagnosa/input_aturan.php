<?php
echo"<h2><a  href='?page=input_aturan'><i class='fa fa-plus'></i> Tambah Aturan</a></h2><hr>";


?>

<div class="jumbotron">

<center><h4>Aturan</h4></center>
<br>
<form class="form-horizontal" method="post" action="">
  <div class="form-group">
    <label for="Gejala" class="col-md-3 col-md-offset-1 control-label"> Pertanyaan</label>
    <div class="col-sm-5">
      <input type="text" class="form-control" name="pertanyaan">
    </div>
  </div>
  <div class="form-group">
    <label for="Gejala" class="col-md-3 col-md-offset-1 control-label">Bila Benar</label>
    <div class="col-sm-5">
      <input type="text" class="form-control" name="fakta_ya">
    </div>
  </div>
   <div class="form-group">
    <label for="Gejala" class="col-md-3 col-md-offset-1 control-label">Bila Salah</label>
    <div class="col-sm-5">
      <input type="text" class="form-control" name="fakta_tidak">
    </div>
  </div>
   <div class="form-group">
    <label for="Gejala" class="col-md-3 col-md-offset-1 control-label">n Gejala Persalinan Normal</label>
    <div class="col-sm-5">
      <input type="text" class="form-control" name="ngejala_akut">
    </div>
  </div>
      <div class="form-group">
    <label for="Gejala" class="col-md-3 col-md-offset-1 control-label">n Gejala Sectio Caesarea</label>
    <div class="col-sm-5">
      <input type="text" class="form-control" name="ngejela_kronis">
    </div>
  </div>
   <div class="form-group">
    <label for="Gejala" class="col-md-3 col-md-offset-1 control-label">Rute</label>
    <div class="col-sm-5">
      <input type="text" class="form-control" name="rute">
    </div>
  </div>
     <div class="form-group">
    <label for="Gejala" class="col-md-3 col-md-offset-1 control-label">Status</label>
    <div class="col-sm-5">
      <input type="text" class="form-control" name="rute">
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-offset-4 col-sm-5">
      <button type="submit" class="btn btn-theme">Tambah</button>
    </div>
  </div>
</form>
</div>