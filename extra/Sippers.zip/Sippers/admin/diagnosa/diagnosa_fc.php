<?php echo "<h2><a  href='?page=diagnosa_fc'><i class='fa fa-plus'></i> Diagnosa</a></h2><hr>";
 ?>
<div class="jumbotron">
<center><h2><u>Diagnosa Persalinan</u></h2></center>
<br/>
<center><p>Disini, anda dapat melakukan diagnosa mandiri untuk mengetahui proses persalinan apa yang sebaiknya ada lakukan apakah persalinan normal atau sectio caesarea. Anda hanya perlu menjawab setiap pertanyaan berkaitan dengan kondisi / keluhan yang anda rasakan saat ini. Kemudian sistem akan melakukan prediksi berdasarkan jawaban anda.
</p></center>
	<div class="col-sm-offset-5">
      <a href="?page=naive_bayes"><button class="btn btn-primary">Naive Bayes</button></a>
	  <a href="?page=solving_konsul"><button class="btn btn-success">Forward Chaining</button></a>
    </div>
</div>