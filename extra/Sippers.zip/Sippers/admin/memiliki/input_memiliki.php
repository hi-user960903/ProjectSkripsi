<?php
include "../config/koneksi.php"; //memanggil file koneksi_db.php
include "../config/config.php"; //memanggil file fungsi.php
include "../config/fungsi.php"; //memanggil file fungsi.php
include "../config/fungsi_thumb.php";

echo"<h2><a  href='?page=input_memiliki'><i class='fa fa-plus'></i> Tambah Relasi Memiliki</a></h2><hr>";	
?>

<div class="jumbotron">
<center><h4>Relasi Memiliki</h4></center>
<form class="form-horizontal" method="post"  action="?page=act_input_memiliki">
  <div class="form-group">
    <label for="Gejala" class="col-md-3 col-md-offset-1 control-label">Konsul Diagnosa</label>
    <div class="col-sm-5">
	  <select class="form-control" name="id_kd">
	<?php 
			$qt= mysqli_query($con,"SELECT * from konsul_diagnosa");
			while ($hasil=mysqli_fetch_array($qt)) {
			   echo "
						<option name value='$hasil[id_kd]'>$hasil[gejala_dan_kerusakan]</option>
					";
			}
	  ?>
	  </select>
    </div>
  </div>
  <div class="form-group">
    <label for="Gejala" class="col-md-3 col-md-offset-1 control-label">Solusi</label>
    <div class="col-sm-5">
	 <select class="form-control" name="id_solusi">
      <?php 
		$query= mysqli_query($con,"SELECT * from solusi");
		while ($hasil=mysqli_fetch_array($query)) {
		   echo "
					<option value='$hasil[id_solusi]'>$hasil[nama_kerusakan]</option>";
		  }
	  ?>
	  </select>
    </div>
  </div>
  
   <div class="form-group">
    <div class="col-sm-offset-4 col-sm-5">
      <button type="submit" class="btn btn-theme">Tambah</button>
    </div>
  </div>
</form>
</div>