<?php
include "../config/koneksi.php";
echo "<h2><a  href='?page=edit_memiliki'><i class='fa fa-edit'></i> Edit Relasi Memiliki</a></h2><hr>";

$id=$_GET['id'];
if ($id=="") {
echo "<script>alert('Pilih dulu data yang akan di-update');</script>";
echo "<meta http-equiv='refresh' content='0; url=?page=memiliki'>";
} else {

$query=mysqli_query($con,"SELECT  a.id_kd, a.gejala_dan_kerusakan, b.id_solusi, b.nama_kerusakan, c.* 
							from memiliki C 
							join konsul_diagnosa A on a.id_kd=c.id_kd 
							join solusi B on b.id_solusi=c.id_solusi  WHERE c.id_kd=$id ");

?>

<div class="jumbotron">
<center><h4>Rule Diagnosa</h4></center>
<br>
<form class="form-horizontal" method="post" action="?page=act_edit_memiliki" enctype="multipart/form-data">
<input type="hidden" name="id" value="<?php echo $id; ?>">
<br>
  <div class="form-group">
    <label for="Gejala" class="col-md-3 col-md-offset-1 control-label">Konsul Diagnosa</label>
    <div class="col-sm-5">
      <select class="form-control" name="id_solusi">
      <?php 
		while ($hasil=mysqli_fetch_array($query)) {
		   echo "
					<option value='$hasil[id_kd]'>$hasil[gejala_dan_kerusakan]</option>";
		  }
	  ?>
	  </select>
    </div>
  </div>
  <div class="form-group">
    <label for="Gejala" class="col-md-3 col-md-offset-1 control-label">Solusi</label>
    <div class="col-sm-5">
      <select class="form-control" name="id_solusi">
      <?php 
		while ($HSL=mysqli_fetch_array($query)) {
		   echo "
					<option value='$hasil[id_solusi]'>$hasil[nama_kerusakan]</option>";
		  }
	  ?>
	  </select>
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-offset-4 col-sm-5">
      <button type="submit" class="btn btn-theme">Simpan</button>
    </div>
  </div>
</form>
</div>

<?php
}
?>