<?php
	$server = "localhost";
	$username = "root";
	$password = "";
	
	$con = mysqli_connect("$server","$username","$password");
	$db = mysqli_select_db($con,"sippers");
	
?>
