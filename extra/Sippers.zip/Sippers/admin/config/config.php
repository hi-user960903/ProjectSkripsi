<?php

$maks_pinjam		= 2; //maksimal peminjaman
$maks_hari_pinjam	= 7; //maksimal hari peminjaman
$instansi			= "nama_instansi";
$alamat				= "alamat_instansi";
$logo				= "C:\wamp\perpus\images\logo.gif";
?>
