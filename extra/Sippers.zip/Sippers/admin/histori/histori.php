<?php

include "../config/koneksi.php";
include "../config/fungsi.php";
include "../config/class_paging.php";
echo"<h2><a  href='?page=histori'><i class='fa fa-list-alt'></i> Histori Konsultasi</a></h2><hr>";

$p      = new Paging;
$batas  = 10;
$posisi = $p->cariPosisi($batas);

?>
<div class="col-sm-12">
<table class="table table-bordered table-striped" >
    <thead class="cf">
    <tr>
	<th>No</th>
	<th width="150">Nama Pasien </th>
	<th>Usia</th>
	<th>Rw Sesar</th>
	<th>Letak Bayi Sungsang</th>
	<th>Rw CPD</th>
	<th>Plasenta Previa</th>
	<th>PEB</th>
	<th>Oligohidriamnion</th>
	<th>Hipertensi</th>
	<th>Hasil </th>
	<th>Hasil NB </th>
	<th>Hasil FC </th>
	<th>Tanggal Kunjung</th>
	</tr>
	</thead>
    <tbody>
<?php
$no=$posisi+1;;
$query= mysqli_query($con,"SELECT * FROM daftar_user WHERE level='pasien' order by id_user ASC  limit $posisi,$batas");
while ($hasil=mysqli_fetch_array($query,MYSQLI_ASSOC)) {

echo "<tr>
	  <td>$no</td>
	  <td>$hasil[nama]</td>";
//usia
$que= mysqli_query($con,"SELECT a.*, b.id_atribut, b.atribut  FROM daftar_memiliki a JOIN daftar_atribut b ON  a.id_atribut=b.id_atribut JOIN daftar_gejala ON a.id_gejala='9'  WHERE a.id_user=".$hasil['id_user']);
$hsl=mysqli_fetch_array($que,MYSQLI_ASSOC);
echo "<td>$hsl[atribut]</td>";
//riwayat sesar
$que= mysqli_query($con,"SELECT a.*, b.id_atribut, b.atribut  FROM daftar_memiliki a JOIN daftar_atribut b ON  a.id_atribut=b.id_atribut JOIN daftar_gejala ON a.id_gejala='2'  WHERE a.id_user=".$hasil['id_user']);
$hsl=mysqli_fetch_array($que,MYSQLI_ASSOC);
echo "<td>$hsl[atribut]</td>";
//letak bayi sungsang
$que= mysqli_query($con,"SELECT a.*, b.id_atribut, b.atribut  FROM daftar_memiliki a JOIN daftar_atribut b ON  a.id_atribut=b.id_atribut JOIN daftar_gejala ON a.id_gejala='3'  WHERE a.id_user=".$hasil['id_user']);
$hsl=mysqli_fetch_array($que,MYSQLI_ASSOC);
echo "<td>$hsl[atribut]</td>";
//riwayat cpd
$que= mysqli_query($con,"SELECT a.*, b.id_atribut, b.atribut  FROM daftar_memiliki a JOIN daftar_atribut b ON  a.id_atribut=b.id_atribut JOIN daftar_gejala ON a.id_gejala='4'  WHERE a.id_user=".$hasil['id_user']);
$hsl=mysqli_fetch_array($que,MYSQLI_ASSOC);
echo "<td>$hsl[atribut]</td>";
//plasenta previa
$que= mysqli_query($con,"SELECT a.*, b.id_atribut, b.atribut  FROM daftar_memiliki a JOIN daftar_atribut b ON  a.id_atribut=b.id_atribut JOIN daftar_gejala ON a.id_gejala='5'  WHERE a.id_user=".$hasil['id_user']);
$hsl=mysqli_fetch_array($que,MYSQLI_ASSOC);
echo "<td>$hsl[atribut]</td>";
//PEB
$que= mysqli_query($con,"SELECT a.*, b.id_atribut, b.atribut  FROM daftar_memiliki a JOIN daftar_atribut b ON  a.id_atribut=b.id_atribut JOIN daftar_gejala ON a.id_gejala='6'  WHERE a.id_user=".$hasil['id_user']);
$hsl=mysqli_fetch_array($que,MYSQLI_ASSOC);
echo "<td>$hsl[atribut]</td>";
//oligohidroamnion
$que= mysqli_query($con,"SELECT a.*, b.id_atribut, b.atribut  FROM daftar_memiliki a JOIN daftar_atribut b ON  a.id_atribut=b.id_atribut JOIN daftar_gejala ON a.id_gejala='7'  WHERE a.id_user=".$hasil['id_user']);
$hsl=mysqli_fetch_array($que,MYSQLI_ASSOC);
echo "<td>$hsl[atribut]</td>";
//hipertensi
$que= mysqli_query($con,"SELECT a.*, b.id_atribut, b.atribut  FROM daftar_memiliki a JOIN daftar_atribut b ON  a.id_atribut=b.id_atribut JOIN daftar_gejala ON a.id_gejala='8'  WHERE a.id_user=".$hasil['id_user']);
$hsl=mysqli_fetch_array($que,MYSQLI_ASSOC);
echo "<td>$hsl[atribut]</td>";
$que= mysqli_query($con,"SELECT id_user, hasil from daftar_user WHERE id_user=".$hasil['id_user']);
$hsl=mysqli_fetch_array($que,MYSQLI_ASSOC);
echo "<td>$hsl[hasil]</td>
	  <td></td>
	  <td></td>
	  <td></td>
	  </tr>";
$no++;
}
echo'</tbody></table></div>';
?>
<div class="col-sm-6">
<table class="table table-bordered table-striped" >
    <thead class="cf">
    <tr>
		<th>No</th>
		<th>Prediksi</th>
		<th>Dataset</th>
		<th>Naive Bayes</th>
		<th>Forward Chaining</th>
	</tr>
	</thead>
    <tbody>
<?php
$a=1;;
$query= mysqli_query($con,"SELECT * FROM daftar_penyakit  order by id_penyakit ASC ");
while ($hasil=mysqli_fetch_array($query,MYSQLI_ASSOC)) {
		echo"<tr>";
		echo"<td>$a</td>";
		echo"<td>$hasil[penyakit]</td>";
        $dpn = mysqli_num_rows(mysqli_query($con,"SELECT hasil FROM daftar_user where daftar_user.hasil='".$hasil['penyakit']."' "));
		echo"<td>$dpn</td>";
		echo"<td></td>";
		echo"<td></td>";
		echo"</tr>";
$a++;
}
		echo"</tbody>";
		echo"</table>";
		echo"</div>";
		echo"<div class=\"col-sm-12\">";

	$jmldata = mysqli_num_rows(mysqli_query($con,"SELECT * FROM daftar_memiliki"));
    $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
    $linkHalaman = $p->navHalaman($_GET['halaman'], $jmlhalaman);

echo "<div id=paging>Hal: $linkHalaman</div><br>";
?>
</div>