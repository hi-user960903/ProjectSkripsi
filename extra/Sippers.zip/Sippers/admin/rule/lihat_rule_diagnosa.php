<?php
include "../config/koneksi.php"; //memanggil file koneksi_db.php
include "../config/fungsi.php";
include "../config/class_paging.php";
echo"<h2><a  href='?page=rule_diagnosa'><i class='fa fa-list-alt'></i> Data Rule Diagnosa</a></h2><hr>";


$p      = new Paging;
$batas  = 10;
$posisi = $p->cariPosisi($batas);


$query=mysqlI_query($con,"SELECT * from konsul_diagnosa order by id_kd  LIMIT $posisi,$batas");
?>
<form method="post" action="?page=input_rule_diagnosa">
<br> 
<br><table class="table table-bordered table-striped">
    <thead class="cf">
    <tr>
	<th>No</th>
	<th>Id KD</th>
	<th>Rule Gejala</th>
	<th>Bila Benar</th>
	<th>Bila Salah </th>
	<th>Mulai</th>
	<th>Selesai </th>
	<th colspan='2'><center>Action</th>
	</tr>
	</thead>
    <tbody>
<?php
$no=$posisi+1;;
while ($hasil=mysqli_fetch_array($query,MYSQLI_ASSOC)) {

echo "<tr>
	  <td>$no</td>
	  <td>$hasil[id_kd]</td>
	  <td>$hasil[gejala_dan_kerusakan]</td>
	  <td>$hasil[bila_benar]</td>
	  <td>$hasil[bila_salah]</td>
	  <td>$hasil[mulai]</td>
	  <td>$hasil[selesai]</td>
	  <td>
		<center><a href='?page=edit_rule_diagnosa&id=$hasil[id_kd]'><button type='button' class='btn btn-theme'><i class='fa fa-edit'></i></button></a></center>
	  </td>
	  <td>
		<center><a href='?page=hapus_rule_diagnosa&id=$hasil[id_kd]' onclick='return confirm(\"Anda yakin ingin menghapus data ini ?\")'> <button type='button' class='btn btn-danger'> <i class='fa fa-trash-o'></i></button></a></center>
	  </td>
	  </tr>";
$no++;
}
echo' </tbody></table></form>
<center><button class="btn btn-theme" type="submit" >Tambah</button></center>
';
	$jmldata = mysqli_num_rows(mysqli_query($con,"SELECT * FROM konsul_diagnosa"));
    $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
    $linkHalaman = $p->navHalaman($_GET['halaman'], $jmlhalaman);

echo "<div id=paging>Hal: $linkHalaman</div><br>";

?>