<!doctype html>
<?php
	include 'config.php';
	
	if (!isset($_SESSION['username'])){
		header ('location:index.php?valid=0');
	}
?>
<html style="background:#000;">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, maximum-scale=1">
<title>SiPPerS</title>
<link rel="icon" href="img/favicon.png" type="image/png">
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/style.css" rel="stylesheet" type="text/css"> 
<link href="css/font-awesome.css" rel="stylesheet" type="text/css"> 
<link href="css/animate.css" rel="stylesheet" type="text/css">
 
<!--[if lt IE 9]>
    <script src="js/respond-1.1.0.min.js"></script>
    <script src="js/html5shiv.js"></script>
    <script src="js/html5element.js"></script>
<![endif]-->
 
</head>
<body>

<!--Header_section-->
<header id="header_wrapper">
  <div class="container">
    <div class="header_box">
      <div class="logo"><a href="#"><img src="img/logo1.png" alt="logo" width="140"></a></div>
	  <nav class="navbar navbar-inverse" role="navigation">
      <div class="navbar-header">
        <button type="button" id="nav-toggle" class="navbar-toggle" data-toggle="collapse" data-target="#main-nav"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
        </div>
	    <div id="main-nav" class="collapse navbar-collapse navStyle">
			<ul class="nav navbar-nav" id="mainNav">
			  <?php
					if ($_SESSION['level']== 'admin'){
						echo "<li><a href='admin/theme/index.php?page=user'>Kembali</a></li>";
					}elseif($_SESSION['level']== 'pasien'){
						echo "<li><a href='index.php>Kembali</a></li>";
					}
				?>
			   <li><a href="logout.php">Logout</a></li>
			</ul>
      </div>
	 </nav>
    </div>
  </div>
</header>
<!--Header_section--> 

<!--Hero_Section-->
<section id="hero_section" class="top_cont_outer">
  <div class="hero_wrapper" id="hero_periksa">
	  	<?php
			if (isset($_GET['simpan'])){
				echo "<div class=\"alert alert-success\" style=\"position:fixed; width:100%;\">";
				echo "<a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">&times;</a>";
				echo "<strong>Penyimpanan Berhasil!</strong> Data berhasil disimpan.";
				echo "</div>";
			}
		?>
    <div class="container">
      <div class="hero_section">
        <div class="row">
          <div class="col-lg-7 col-sm-6">
            <div class="top_left_cont zoomIn wow animated">
			<?php
				$page	= isset($_GET['page']) ? $_GET['page'] : "";
				if($page=="forward_c") {
				include "diagnosa/solving_konsul.php";
				} else if ($page=="solving_konsultes") {
				include "diagnosa/solving_konsultes.php";
				} else if ($page=="analisa_diagnosa_konsul") {
				include "diagnosa/analisa_diagnosa_konsul.php";
				}
				else if ($page=="naive_bayes") {
				include "diagnosa/naive_bayes.php";
				} else {
				include "info_periksa.php";
				}
			?>
			 </div>
          </div>
          <div class="top_left_cont col-lg-5 col-sm-5">
			<h2>Data User</h2>
			<table class="table table" id="tabel_user">
				<tbody>
				<?php
					if ($_SESSION['level']== 'admin'){
						$id=$_GET['id'];
						if ($id=="") {
						die;
						} else {
						$ssql =mysqli_query ($con, "SELECT * FROM daftar_user WHERE id_user = $id");
						
						while ($record = mysqli_fetch_array($ssql)){
							
							$lahir = substr($record['tgl_lahir'], 0, 4);
							$now = date ('Y');
							$usia = $now - $lahir;
							
							echo "<tr>";
							echo "<td>Nama Lengkap</td>";
							echo "<td>".$record['nama']."</td>";
							echo "</tr>";
							echo "<tr>";
							echo "<td>Usia</td>";
							echo "<td>$usia tahun</td>";
							echo "</tr>";
							echo "<tr>";
							echo "<td>Tanggal diagnosa terakhir</td>";
							echo "<td>".$record['tgl_diagnosa']."</td>";
							echo "</tr>";
							echo "<tr>";
							echo "<td>Hasil</td>";
							echo "<td>".$record['keterangan']."</td>";
							echo "</tr>";
						}
					}

					}elseif($_SESSION['level']== 'pasien'){
						$ssql = "SELECT * FROM daftar_user WHERE username = '".$_SESSION['username']."'";
						$query = mysqli_query($con,$ssql);
						
						while ($record = mysqli_fetch_array($query)){
							
							$lahir = substr($record['tgl_lahir'], 0, 4);
							$now = date ('Y');
							$usia = $now - $lahir;
							
							echo "<tr>";
							echo "<td>Nama Lengkap</td>";
							echo "<td>".$record['nama']."</td>";
							echo "</tr>";
							echo "<tr>";
							echo "<td>Usia</td>";
							echo "<td>$usia tahun</td>";
							echo "</tr>";
							echo "<tr>";
							echo "<td>Tanggal diagnosa terakhir</td>";
							echo "<td>".$record['tgl_diagnosa']."</td>";
							echo "</tr>";
							echo "<tr>";
							echo "<td>Hasil</td>";
							echo "<td>".$record['keterangan']."</td>";
							echo "</tr>";
						}
					}
			  ?>
				</tbody>
			</table>
			<?php
					if ($_SESSION['level']== 'admin'){
						$id=$_GET['id'];
						if ($id=="") {
						echo "<script>alert('Pilih dulu data yang akan di-update');</script>";
						echo "<meta http-equiv='refresh' content='0; url=admin/theme/index.php?page=user'>";
						} else {
						$ssql = "SELECT * FROM daftar_user WHERE id_user=$id";
						$query = mysqli_query($con,$ssql);
						echo "<div class=\"top_left_cont col-lg-12 col-sm-12\">
							  <h2>Riwayat User</h2>
						      <table class=\"table table\" id=\"tabel_user\">
							  <tbody>";					
						while ($record = mysqli_fetch_array($query)){
							echo "<tr>";
							echo "<td>Nama Lengkap</td>";
							echo "<td>".$record['nama']."</td>";
							echo "</tr>";
							echo "<tr>";
							echo "<td>Hasil</td>";
							echo "<td>".$record['hasil']."</td>";
							echo "</tr>";
							$atri = mysqli_query($con, "SELECT a.id_user, a.id_gejala, a.id_atribut, b.id_gejala, b.gejala, c.id_atribut, c.atribut FROM daftar_memiliki a, daftar_gejala b, daftar_atribut c WHERE a.id_gejala=b.id_gejala AND a.id_atribut=c.id_atribut AND a.id_user=$id order by b.id_gejala asc");
							while ($hasil=mysqli_fetch_array($atri)){
							echo "<tr>";
							echo "<td>".$hasil['gejala']. "</td>";
							echo "<td>".$hasil['atribut']."</td>";
							echo "</tr>";
							}
							echo "</tbody>
								  </table>";
						}
					}
					}elseif($_SESSION['level']== 'pasien'){
						echo "<img src=\"img/tesicon.png\"/>";
					}
			  ?>
		  </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!--Hero_Section--> 
<?php
	include_once 'template/footer.php';
?>