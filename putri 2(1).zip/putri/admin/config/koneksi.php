<?php

	$host = "host.docker.internal";
	$user = "susanto";
	$pass = "susanti";
	$db = "putri";
	$dbname = "putri";
	
	$con = mysqli_connect("$host","$user","$pass");
	$db = mysqli_select_db($con,$db);
	
	
?>
