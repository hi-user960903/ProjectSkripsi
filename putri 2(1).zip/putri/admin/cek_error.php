<?php
if (!$query) {
    printf("Error: %s\n", mysqli_error($con));
    exit();
}
?>