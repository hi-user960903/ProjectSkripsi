<!doctype html>
<?php
	include 'config.php';
?>
<html style="background:#000;">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, maximum-scale=1">
<title>SiPPerS</title>
<link rel="icon" href="img/favicon.png" type="image/png">
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/style.css" rel="stylesheet" type="text/css"> 
<link href="css/font-awesome.css" rel="stylesheet" type="text/css"> 
<link href="css/animate.css" rel="stylesheet" type="text/css">
 
<!--[if lt IE 9]>
    <script src="js/respond-1.1.0.min.js"></script>
    <script src="js/html5shiv.js"></script>
    <script src="js/html5element.js"></script>
<![endif]-->
 
</head>
<body>

<!--Header_section-->
<header id="header_wrapper">
  <div class="container">
    <div class="header_box">
      <div class="logo"><a href="#"><img src="img/logo1.png" alt="logo" width="140"></a></div>
	  <nav class="navbar navbar-inverse" role="navigation">
      <div class="navbar-header">
        <button type="button" id="nav-toggle" class="navbar-toggle" data-toggle="collapse" data-target="#main-nav"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
        </div>
	    <div id="main-nav" class="collapse navbar-collapse navStyle">
			<ul class="nav navbar-nav" id="mainNav">		
				<li><a href='index.php'>Kembali</a></li>
			</ul>
      </div>
	 </nav>
    </div>
  </div>
</header>
<!--Header_section--> 

<?php echo "<h2><a  href='?page=input_user'><i class='fa fa-code'></i> Pengujian Naive Bayes</a></h2><hr>";
 ?>

<div class="jumbotron">

<center><h4>Pengujian</h4></center>
<br>
<form class="form-horizontal" method="POST" action="periksa_nbc_act.php">
<br>
    <div class="form-group">
    <label for="Gejala" class="col-md-3 col-md-offset-1 control-label">Nama Pasien</label>
    <div class="col-sm-5">
      <input type="text" class="form-control" name="nama">
    </div>
  </div>
  <?php
  $query= mysqli_query($con,"SELECT * FROM nbc_atribut where id_atribut > 1 ORDER BY id_atribut");	
  $a=0;
  while ($hasil=mysqli_fetch_array($query)) {
      echo " <div class='form-group'>
                <label class='col-md-3 col-md-offset-1 control-label'>$hasil[atribut]</label>
                <div class='col-sm-5'>";

      $param = mysqli_query($con,"SELECT * FROM nbc_parameter where id_atribut = ".$hasil['id_atribut']." ORDER BY nilai");

      while($r_param=mysqli_fetch_array($param))
      {
          $id_atribut = $hasil['id_atribut'];
          $nm_param = $r_param['parameter'];
          $nilai = $r_param['nilai'];
          echo "<label><input type='radio' name='atribut_$id_atribut' value='$nilai' required> $nm_param</label>
          <br>";
      }
      echo "</div></div>";
      $a++;
  }
  ?>
	
  <div class="form-group">
    <div class="col-sm-offset-4 col-sm-5">
      <button type="submit" class="btn btn-theme">Proses</button>
    </div>
  </div>
</form>
</div>


<!--Hero_Section--> 
<?php
	include_once 'template/footer.php';
?>